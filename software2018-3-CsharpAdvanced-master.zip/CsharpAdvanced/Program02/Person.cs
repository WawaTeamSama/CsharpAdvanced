﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Program02
{
    public class Person
    {
        //名
        public string FirstName { get; set; }

        //姓
        public string LastName { get; set; }

        //表达式体的属性
        public string FullName => $"{FirstName}{LastName}";

        //年龄
        public int Age { get; set; } = 20;

        //性别   只读
        public bool Sex { get; private set; } = true;
    }
}