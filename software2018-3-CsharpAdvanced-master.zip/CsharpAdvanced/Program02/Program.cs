﻿using System;

namespace Program02
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            //匿名类型
            var doctor = new
            {
                FirstName = "张",
                LastName = "三"
            };
            Console.WriteLine(doctor.FirstName);
            Console.WriteLine(doctor.LastName);
            Console.WriteLine(doctor.FirstName + doctor.LastName);
        }
    }
}