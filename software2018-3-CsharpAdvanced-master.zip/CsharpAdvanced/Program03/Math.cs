﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Program03
{
    public class Math
    {
        public int Value { get; set; }

        //计算平方，表达式方法
        public int GetSquare() => Value * Value;

        //计算平方，静态表达式方法
        public static int GetSquareOf(int x) => x * x;
    }
}