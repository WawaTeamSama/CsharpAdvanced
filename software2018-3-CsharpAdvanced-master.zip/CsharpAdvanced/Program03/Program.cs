﻿using System;

namespace Program03
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            var math = new Math();
            math.Value = 30;
            Console.WriteLine("{0}的平方等于{1}", math.Value, math.GetSquare());

            Console.WriteLine("{0}的平方等于{1}", 20, Math.GetSquareOf(20));
        }
    }
}