﻿using System;

namespace Program04
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            var t = new Ticket(400);
            t.ShowTicket();
        }
    }
}