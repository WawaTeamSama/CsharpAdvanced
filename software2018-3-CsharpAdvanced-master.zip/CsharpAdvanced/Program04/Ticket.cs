﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Program04
{
    //写一个Ticket类,有一个距离属性(本属性只读,在构造方法中赋值),
    //不能为负数,有一个价格属性,价格属性只读,
    //并且根据距离distance计算价格Price (1元/公里):
    //0-100公里 票价不打折
    //101-200公里 总额打9.5折
    //201-300公里 总额打9折
    //300公里以上 总额打8折
    public class Ticket
    {
        public Ticket(double distance)
        {
            //距离大于0
            this.Distance = distance > 0 ? distance : 0;
        }

        //属性只读
        public double Distance { get; }

        //0-100公里 票价不打折
        //101-200公里 总额打9.5折
        //201-300公里 总额打9折
        //300公里以上 总额打8折
        public double Price => (Distance > 0 && Distance <= 100)
            ? Distance * 1.0
            : (Distance > 101 && Distance < 200
                ? Distance * 0.95
                : (Distance > 201 && Distance < 300 ? Distance * 0.9 : Distance * 0.8));

        public void ShowTicket()
        {
            Console.WriteLine("{0}公里需要{1:C}元", Distance, Price);
        }
    }
}