﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Program05
{
    //课程2
    public class Course2
    {
        //课程各
        public string Name { get; set; }

        //学时
        private int _period;

        public int Period
        {
            get => _period;
            set => _period = value < 0 ? 0 : value;
        }

        //学分
        private int _credit;

        public int Creidt
        {
            get => _credit;
            set => _credit = value < 0 ? 0 : value;
        }

        //成绩
        private int _score;

        public int Score
        {
            get => _score;
            set => _score = value < 0 || value > 100 ? 0 : value;
        }

        public override string ToString() => $" 课程：{Name}，学时：{Period}，学分：{Creidt}，成绩：{Score}";
    }
}