﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Program05
{
    //成绩管理类
    public class GradeManage
    {
        public Student Stu { get; }
        public Course1 C1 { get; }
        public Course2 C2 { get; }

        //总分
        public int Sum { get; }

        public GradeManage()
        {
        }

        //只初始化学生信息的构造方法
        public GradeManage(string stuNo, string stuName, int age)
        {
            Stu = new Student()
            {
                No = stuNo,
                Name = stuName,
                Age = age
            };
        }

        //带课程的构造方法
        public GradeManage(string stuNo, string stuName, int age,
            string cName1, int cPeriod1, int cCredit1, int cScore1,
            string cName2, int cPeriod2, int cCredit2, int cScore2)
        {
            Stu = new Student()
            {
                No = stuNo,
                Name = stuName,
                Age = age
            };

            C1 = new Course1()
            {
                Name = cName1,
                Period = cPeriod1,
                Creidt = cCredit1,
                Score = cScore1
            };

            C2 = new Course2()
            {
                Name = cName2,
                Period = cPeriod2,
                Creidt = cCredit2,
                Score = cScore2
            };

            Sum = C1.Score + C2.Score;
        }

        //打印方法
        public void Print() => Console.WriteLine($"{Stu}{C1}{C2} 总分：{Sum}");
    }
}