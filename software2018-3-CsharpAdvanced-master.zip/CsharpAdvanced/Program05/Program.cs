﻿using System;

namespace Program05
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            // var gm = new GradeManage("2018001", "Messi", 20);

            var gm = new GradeManage("2018001", "Messi", 20,
                "语文", 60, 4, 98,
                "数学", 56, 4, 99);
            gm.Print();
        }
    }
}