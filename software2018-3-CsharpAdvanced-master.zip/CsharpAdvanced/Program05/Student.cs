﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace Program05
{
    public class Student
    {
        //学号
        public string No { get; set; }

        //姓名
        public string Name { get; set; }

        private int _age { get; set; }

        public int Age
        {
            get => _age;
            set => _age = value > 150 || value < 0 ? 0 : value;
        }

        public override string ToString() => $"学号：{No}，姓名：{Name}，年龄：{Age}";
    }
}