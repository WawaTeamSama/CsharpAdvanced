﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;

namespace Program06_CashShop
{
    /// <summary>
    /// 实现原价打xx折
    /// </summary>
    public class CashRebate : CashSuper
    {
        private double _moneyRebate = 1.0d;

        public CashRebate(double moneyRebate)
        {
            this._moneyRebate = moneyRebate;
        }

        public override decimal AcceptCash(decimal money)
        {
            return money * (decimal)_moneyRebate;
        }
    }
}