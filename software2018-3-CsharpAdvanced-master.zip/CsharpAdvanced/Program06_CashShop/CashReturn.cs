﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Program06_CashShop
{
    public class CashReturn : CashSuper
    {
        //满减的条件
        private decimal _moneyCondition = 0.0M;

        //满减后返现金额
        private decimal _moneyReturn = 0.0M;

        public CashReturn(decimal moneyCondition, decimal moneyReturn)
        {
            this._moneyCondition = moneyCondition;
            this._moneyReturn = moneyReturn;
        }

        public override decimal AcceptCash(decimal money)
        {
            var totalPrice = money;
            if (money > _moneyCondition)
                totalPrice = money - Math.Floor(money / _moneyCondition) * _moneyReturn;
            return totalPrice;
        }
    }
}