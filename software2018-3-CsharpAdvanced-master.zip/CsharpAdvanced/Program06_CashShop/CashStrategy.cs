﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Program06_CashShop
{
    /// <summary>
    /// 打折策略选择
    /// </summary>
    public class CashStrategy
    {
        private CashSuper _cs;
        private double _rebate;

        //满减的条件
        private decimal _moneyCondition;

        //满减后返现金额
        private decimal _moneyReturn;

        public CashStrategy(string type, double rebate = 1, decimal moneyCondition = 0M, decimal moneyReturn = 0M)
        {
            switch (type)
            {
                case "Normal":
                    this._cs = new CashNormal();
                    break;

                case "Rebate":
                    this._cs = new CashRebate(rebate);
                    break;

                //新打折策略
                case "Return":
                    this._cs = new CashReturn(moneyCondition, moneyReturn);
                    break;
            }
        }

        public decimal GetTotal(decimal money)
        {
            return _cs.AcceptCash(money);
        }
    }
}