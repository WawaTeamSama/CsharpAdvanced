﻿using System;

namespace Program06_CashShop
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            //总价
            decimal totalPrice = 0M;
            Console.WriteLine("请选择打择方式（1-原价，2-打9折，3-打8折,4-满200减10）:");
            var type = Console.ReadLine();

            CashStrategy cs;
            switch (type)
            {
                case "1":
                    cs = new CashStrategy("Normal");
                    totalPrice += cs.GetTotal(100);
                    break;

                case "2":
                    cs = new CashStrategy("Rebate", 0.9);
                    totalPrice += cs.GetTotal(100);
                    break;

                case "3":
                    cs = new CashStrategy("Rebate", 0.8);
                    totalPrice += cs.GetTotal(100);
                    break;

                case "4":
                    cs = new CashStrategy("Return", 1, 200M, 10M);
                    totalPrice += cs.GetTotal(300);
                    break;

                default:
                    break;
            }
            Console.WriteLine("原价:300，应付:" + totalPrice);
        }
    }
}