﻿using System;
using System.Collections.Generic;
using System.Text;

namespace program01
{
    public class Person
    {
        //private string _name;
        ////姓名属性
        //public string Name
        //{
        //    get=>_name;
        //    set=>_name=value;
        //}

        //名
        public string FirstName { get; set; }

        //姓
        public string LastName { get; set; }

        //表达式体的属性
        public string FullName => $"{FirstName}{LastName}";

        //年龄
        public int Age { get; set; } = 20;

        //性别   只读
        public bool Sex { get; private set; } = true;
    }
}