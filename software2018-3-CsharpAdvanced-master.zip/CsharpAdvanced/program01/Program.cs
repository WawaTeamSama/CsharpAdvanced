﻿using System;

namespace program01
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            var person = new Person()
            {
                FirstName = "张",
                LastName = "三",
                Age = 30,
                //Sex = false
            };

            Console.WriteLine(person.FullName);
            Console.WriteLine(person.Age);
            Console.WriteLine(person.Sex ? "男" : "女");
        }
    }
}